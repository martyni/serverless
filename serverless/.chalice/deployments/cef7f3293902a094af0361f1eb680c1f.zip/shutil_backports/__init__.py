__title__ = "shutil_backports"
__version__ = "0.1.0"
__license__ = "MIT"
__author__ = "Christopher Rosell"
__copyright__ = "Copyright 2014 Christopher Rosell"

__all__ = ["get_terminal_size"]

from .get_terminal_size import *
