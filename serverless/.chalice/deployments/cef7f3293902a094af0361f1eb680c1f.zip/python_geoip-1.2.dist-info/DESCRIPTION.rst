python-geoip
============

python-geoip is a library that provides access to GeoIP databases.
Currently it only supports accessing MaxMind databases.  It's similar to
other GeoIP libraries but comes under the very liberal BSD license and
also provides an extra library that optionally ships a recent version of
the Geolite2 database as provided by MaxMind.

Documentation is available at http://pythonhosted.org/python-geoip/

